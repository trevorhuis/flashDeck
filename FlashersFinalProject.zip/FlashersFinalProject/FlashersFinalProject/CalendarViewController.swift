//
//  CalendarViewController.swift
//  FlashersFinalProject
//
//  Created by Trevor on 4/26/19.
//  Copyright © 2019 Tyson Smiter & Ryan Cree. All rights reserved.
//

import UIKit
import EventKit

class CalendarViewController: UIViewController {
    
    // 1
    let eventStore = EKEventStore()
    
    @IBOutlet weak var stepper: UIStepper!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var studyHours: UILabel!
    @IBOutlet weak var studyTitle: UITextField!
    
    
    @IBAction func setReminder(_ sender: Any) {
        if studyTitle.text != "" && stepper.value != 0.0{
            switch EKEventStore.authorizationStatus(for: .event) {
            case .authorized:
                insertEvent(store: eventStore)
            case .denied:
                print("Access denied")
            case .notDetermined:
                // 3
                eventStore.requestAccess(to: .event, completion:
                    
                    {[weak self] (granted: Bool, error: Error?) -> Void in
                        if granted {
                            self!.insertEvent(store: self!.eventStore)
                        } else {
                            print("Access denied")
                        }
                })
            default:
                print("Case default")
            }
        }
        
        
    }
    
    @IBAction func hoursStepper(_ sender: Any) {
        studyHours.text = String(stepper.value)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        stepper.wraps = true
        stepper.autorepeat = true
        studyHours.text = String(stepper.value)
        stepper.maximumValue = 12

        
        
    }
    
    func insertEvent(store: EKEventStore) {
        // 1
        let calendars = store.calendars(for: .event)
        
        for calendar in calendars {
            // 2
            if calendar.title == "Calendar" {
                // 3
                let startDate = datePicker.date

                // 2 hours
                let endDate = startDate.addingTimeInterval(stepper.value * 60 * 60)
                
                // 4
                let event = EKEvent(eventStore: store)
                event.calendar = calendar
                
                event.title = studyTitle.text
                event.startDate = startDate
                event.endDate = endDate
                
                // 5
                do {
                    try store.save(event, span: .thisEvent)
                }
                catch {
                    print("Error saving event in calendar")
                }
            }
        }
    }
    
}
