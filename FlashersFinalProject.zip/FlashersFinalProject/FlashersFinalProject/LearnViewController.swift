//
//  LearnViewController.swift
//  FlashersFinalProject
//
//  Created by Luis Carlos Orozco on 4/26/19.
//  Copyright © 2019 Tyson Smiter & Ryan Cree. All rights reserved.
//

import UIKit
import CoreData

class LearnViewController: UIViewController {
    
    //var cards: [NSManagedObject] = []
    
    var cards: [NSManagedObject] = []
    
    var cardID : Int64?
    var deckName: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //1
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Card")
        
        //3
        do {
            cards = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    @IBOutlet weak var scoreAttempt: UILabel!
    
    var score = 0
    var attempt = 0
    
    @IBAction func yesButton(_ sender: Any) {
        score = score + 1
        attempt = attempt + 1
        
        self.scoreAttempt.text = String(score) + "/" + String(attempt)
    }
    @IBAction func noButton(_ sender: Any) {
        attempt = attempt + 1
        
        self.scoreAttempt.text = String(score) + "/" + String(attempt)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
