//
//  ViewController.swift
//  FlashersFinalProject
//
//  Created by Ryan Cree on 4/15/19.
//  Copyright © 2019 Tyson Smiter & Ryan Cree. All rights reserved.
//
import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // Connect the table view
    @IBOutlet weak var tableView: UITableView!
    
    
    var decks: [NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //1
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Deck")
        
        //3
        do {
            decks = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    
    @IBAction func addDeck(_ sender: Any) {
        let alert = UIAlertController(title: "New Deck Name",
                                      message: "Add a new deck",
                                      preferredStyle: .alert)
        
        let saveAction = UIAlertAction(title: "Save", style: .default) {
            [unowned self] action in
            
            guard let textField = alert.textFields?.first,
                let nameToSave = textField.text else {
                    return
            }
            
            self.save(name: nameToSave)
            self.tableView.reloadData()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .cancel)
        
        alert.addTextField()
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true)
    }
    
    func save(name: String) {
        
        let randomID = Int64.random(in: 2 ... 100000) * Int64.random(in: 2 ... 877)
        print("\(randomID)")
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // 1
        let managedContext =
            appDelegate.persistentContainer.viewContext
        
        // 2
        let entity =
            NSEntityDescription.entity(forEntityName: "Deck",
                                       in: managedContext)!
        
        let deck = NSManagedObject(entity: entity,
                                   insertInto: managedContext)
        
        // 3
        deck.setValue(name, forKeyPath: "name")
        deck.setValue(randomID,forKeyPath:"id")
        
        // 4
        do {
            try managedContext.save()
            decks.append(deck)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
        
    {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate
            
            else {
                
                return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        
        
        if editingStyle == .delete
            
        {
            
            do
                
            {
                
                managedContext.delete(decks[indexPath.row])
                
                decks.remove(at: indexPath.row)
                
                tableView.deleteRows(at: [indexPath], with: .fade)
                
                try managedContext.save()
                
                tableView.reloadData()
                
            }
                
            catch
                
            {
                
                let nserror = error as NSError
                
                NSLog("Unable to fetch \(nserror), \(nserror.userInfo)")
                
                abort()
                
            }
            
        }
        
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =
            tableView.dequeueReusableCell(withIdentifier: "deckCell",
                                          for: indexPath) as! deckCell
        let deckName = decks[indexPath.row]
        cell.deckName.text = deckName.value(forKeyPath: "name") as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return decks.count
    }
    
    
    let cardSegueIdentifier = "ShowCardSegue"
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == cardSegueIdentifier,
            let destination = segue.destination as? CardCollectionViewController,
            let chosenRow = tableView.indexPathForSelectedRow?.row
        {
            destination.cardID = decks[chosenRow].value(forKey: "id") as! Int64
            destination.deckName = decks[chosenRow].value(forKey: "name") as! String
            //            destination.name = person.value(forKey: "name") as! String
            //            destination.level = person.value(forKey: "level") as! Int
            //            destination.profession = person.value(forKey: "profession") as! String
            //            destination.attack = person.value(forKey: "attack") as! Float
            //            destination.HP = person.value(forKey: "c_HP") as! Int
            //            destination.image = person.value(forKey: "image") as! String
            //            destination.xp = person.value(forKey: "xp") as! Int
            
        }
    }
}
