//
//  CardCollectionViewCell.swift
//  FlashersFinalProject
//
//  Created by Ryan Cree on 4/22/19.
//  Copyright © 2019 Tyson Smiter & Ryan Cree. All rights reserved.
//

import UIKit

class CardCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cardLabel: UILabel!
}
